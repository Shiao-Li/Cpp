#include <iostream>
#include <string>
using namespace std;

int mostrarMenu();
void sumar();
void restar();
void multiplicar();
void dividir();
void potenciacion();
void raiz_cuadrada();
void factorial();